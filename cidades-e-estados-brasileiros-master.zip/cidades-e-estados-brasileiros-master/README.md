# Base de Cidades e Estados brasileiros.
[![Build Status](https://travis-ci.org/egermano/cidades-e-estados-brasileiros.svg?branch=master)](https://travis-ci.org/egermano/cidades-e-estados-brasileiros)

Arquivos com `inserts` em mysql porém pode servir para qualquer base de dados baseada em sql.

## Para contribuir 

* Faça um fork
* Crie o branch da sua contrinuição
* Solicite um Pull Request do seu novo branch